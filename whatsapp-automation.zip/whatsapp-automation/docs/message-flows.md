# Message Flow Diagrams

Rendered with [Mermaid](https://mermaid.js.org/) — view on GitHub, in VS Code
with the Mermaid extension, or paste into https://mermaid.live.

## 1. Order placed

```mermaid
sequenceDiagram
    participant OS as Order Service
    participant API as API server
    participant DB as SQLite
    participant Q as outbound-messages (BullMQ)
    participant W as Outbound Worker
    participant WA as WhatsApp Cloud API
    participant C as Customer

    OS->>API: POST /api/events/order-placed
    API->>DB: upsert contact
    API->>DB: insert messages row (status=queued)
    API->>Q: enqueue send job
    API-->>OS: 202 Accepted
    Q->>W: deliver job (rate-limited)
    W->>DB: check opt_status
    alt opted_out
        W->>DB: mark message failed (OPTED_OUT)
    else opted_in
        W->>DB: lookup approved template
        W->>WA: send template order_confirmation
        WA-->>W: message id
        W->>DB: mark message sent
        WA->>C: WhatsApp message delivered
        WA-->>API: webhook: status=delivered
        API->>Q: enqueue inbound-events(status)
        Q->>DB: update message status=delivered
    end
```

## 2. Order shipped / out for delivery / delivered

Same shape as order-placed, reusing the `shipping_update` template with
different body variables per stage:

```mermaid
flowchart LR
    A[order.shipped event] --> T1[shipping_update: 'on its way']
    B[order.out_for_delivery event] --> T2[shipping_update: 'out for delivery']
    C[order.delivered event] --> T3[shipping_update: 'delivered']
    T1 & T2 & T3 --> Q[outbound-messages queue] --> WA[WhatsApp Cloud API] --> Cust[Customer]
```

## 3. Cart abandoned (>2 hours)

```mermaid
sequenceDiagram
    participant Cart as Cart/Checkout Service
    participant API as API server
    participant SQ as scheduled-triggers (BullMQ, delayed)
    participant SW as Scheduled Worker
    participant Q as outbound-messages
    participant WA as WhatsApp Cloud API

    Cart->>API: POST /api/events/cart-updated {cartId}
    API->>SQ: add delayed job jobId=cart-<id>, delay=2h
    Note over SQ: If cart updates again before 2h,<br/>re-adding with the same jobId<br/>replaces the pending check (debounce)
    alt customer checks out within 2h
        Cart->>API: POST /api/events/cart-converted {cartId}
        API->>SQ: remove job cart-<id>
        Note over SQ: nudge cancelled — no message sent
    else still abandoned after 2h
        SQ->>SW: deliver delayed job
        SW->>Q: enqueue cart_abandonment send
        Q->>WA: send template (business-hours gated, MARKETING)
    end
```

## 4. Payment failed

```mermaid
flowchart LR
    A[payment.failed webhook from payment gateway] --> B[POST /api/events/payment-failed]
    B --> C[insert messages row]
    C --> D[outbound-messages queue]
    D --> E{opted in?}
    E -- no --> F[mark failed: OPTED_OUT]
    E -- yes --> G[send payment_failed template<br/>with retry-payment link]
    G --> H[WhatsApp Cloud API]
```

## 5. Broadcast campaign (segmented, throttled)

```mermaid
sequenceDiagram
    participant Admin
    participant API as API server
    participant CQ as broadcast-campaigns queue
    participant CW as Campaign Worker
    participant DB as SQLite
    participant OQ as outbound-messages queue
    participant OW as Outbound Worker (global rate limiter)

    Admin->>API: POST /api/campaigns {segmentFilter, throttlePerSecond}
    API->>DB: insert campaign (status=draft)
    Admin->>API: POST /api/campaigns/:id/launch
    API->>CQ: enqueue dispatch job
    CQ->>CW: deliver job
    CW->>DB: resolve audience (opt_status=opted_in AND tags match)
    loop each recipient, spaced by throttlePerSecond
        CW->>DB: insert messages row (campaign_id=x)
        CW->>OQ: enqueue send job (delay=i * gapMs)
    end
    OQ->>OW: jobs consumed at min(campaign throttle, global WA_MAX_MSGS_PER_SECOND)
    OW->>DB: update per-message + campaign counters as receipts arrive
```

## 6. Two-way conversation routing

```mermaid
flowchart TD
    A[Customer sends WhatsApp reply] --> B[Meta POSTs to /webhooks/whatsapp]
    B --> C[verify signature, ack 200 immediately]
    C --> D[enqueue inbound-events job]
    D --> E[Inbound Worker: upsert contact, log message]
    E --> F[parseInboundText]
    F --> G{intent}
    G -- TRACK order --> H[lookup order status, reply inline]
    G -- STOP/UNSUBSCRIBE --> I[opt_status=opted_out + audit log + confirmation reply]
    G -- START/SUBSCRIBE --> J[opt_status=opted_in + confirmation reply]
    G -- CANCEL --> K[flag needs_human_agent=1, holding reply,<br/>never auto-cancels]
    G -- unknown --> L[flag needs_human_agent=1, holding reply]
    K & L --> M[appears in GET /api/contacts?needs_human_agent=1<br/>for a support agent to pick up]
```

## 7. Delivery receipt handling

```mermaid
flowchart LR
    WA[WhatsApp Cloud API] -->|status webhook: sent/delivered/read/failed| WH[/webhooks/whatsapp/]
    WH --> IQ[inbound-events queue]
    IQ --> IW[Inbound Worker]
    IW --> M{find messages row<br/>by wa_message_id}
    M -- found --> U[update status + timestamp column]
    M -- campaign_id set --> N[increment campaign delivered/read/failed counters]
    M -- not found --> LOG[log warning — orphaned receipt]
```
