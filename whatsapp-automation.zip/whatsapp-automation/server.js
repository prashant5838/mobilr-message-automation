const app = require('./src/app');
const config = require('./src/config');
const logger = require('./src/utils/logger');

app.listen(config.port, () => {
  logger.info(
    { port: config.port, mockMode: config.mockMode },
    `WhatsApp automation service listening on :${config.port}${config.mockMode ? ' (MOCK MODE — no WA credentials set)' : ''}`
  );
});
