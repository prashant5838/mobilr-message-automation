const express = require('express');
const db = require('../db/db');
const { campaignQueue } = require('../queues');
const { segmentAudience } = require('../compliance/optIn');

const router = express.Router();

router.get('/', (req, res) => {
  res.json(db.prepare('SELECT * FROM campaigns ORDER BY created_at DESC').all());
});

router.post('/', (req, res) => {
  const {
    name,
    templateName,
    templateLanguage = 'en_US',
    segmentFilter = {},
    throttlePerSecond = 10,
    scheduledAt = null,
  } = req.body;

  if (!name || !templateName) return res.status(400).json({ error: 'name and templateName are required' });

  const audiencePreview = segmentAudience({
    tags: segmentFilter.tags || [],
    optStatus: segmentFilter.opt_status || 'opted_in',
  });

  const info = db
    .prepare(`
      INSERT INTO campaigns (name, template_name, template_language, segment_filter_json, status, scheduled_at, throttle_per_second, total_recipients)
      VALUES (?, ?, ?, ?, 'draft', ?, ?, ?)
    `)
    .run(name, templateName, templateLanguage, JSON.stringify(segmentFilter), scheduledAt, throttlePerSecond, audiencePreview.length);

  res.status(201).json({ id: info.lastInsertRowid, audiencePreviewCount: audiencePreview.length });
});

router.post('/:id/launch', async (req, res) => {
  const id = Number(req.params.id);
  const campaign = db.prepare('SELECT * FROM campaigns WHERE id = ?').get(id);
  if (!campaign) return res.status(404).json({ error: 'Campaign not found' });
  if (campaign.status !== 'draft') return res.status(400).json({ error: `Campaign is '${campaign.status}', cannot launch` });

  db.prepare(`UPDATE campaigns SET status = 'scheduled', updated_at = datetime('now') WHERE id = ?`).run(id);
  await campaignQueue.add('dispatch', { campaignId: id }, campaign.scheduled_at ? { delay: Math.max(0, new Date(campaign.scheduled_at) - Date.now()) } : {});
  res.json({ launched: true, campaignId: id });
});

router.get('/:id', (req, res) => {
  const campaign = db.prepare('SELECT * FROM campaigns WHERE id = ?').get(Number(req.params.id));
  if (!campaign) return res.status(404).json({ error: 'Campaign not found' });
  res.json(campaign);
});

module.exports = router;
