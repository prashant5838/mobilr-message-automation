const express = require('express');
const db = require('../db/db');
const { setOptStatus, getAuditLog } = require('../compliance/optIn');

const router = express.Router();

router.get('/', (req, res) => {
  const { opt_status, needs_human_agent } = req.query;
  let sql = 'SELECT * FROM contacts WHERE 1=1';
  const params = [];
  if (opt_status) { sql += ' AND opt_status = ?'; params.push(opt_status); }
  if (needs_human_agent) { sql += ' AND needs_human_agent = ?'; params.push(Number(needs_human_agent)); }
  sql += ' ORDER BY updated_at DESC LIMIT 200';
  res.json(db.prepare(sql).all(...params));
});

router.post('/:id/opt-status', (req, res) => {
  const contact = db.prepare('SELECT * FROM contacts WHERE id = ?').get(Number(req.params.id));
  if (!contact) return res.status(404).json({ error: 'Contact not found' });
  const { status, source = 'admin_manual' } = req.body;
  if (!['opted_in', 'opted_out'].includes(status)) return res.status(400).json({ error: 'invalid status' });
  const updated = setOptStatus(contact.phone_e164, status, { source });
  res.json(updated);
});

router.get('/:id/audit-log', (req, res) => {
  res.json(getAuditLog(Number(req.params.id)));
});

router.post('/:id/resolve-human-agent', (req, res) => {
  db.prepare('UPDATE contacts SET needs_human_agent = 0 WHERE id = ?').run(Number(req.params.id));
  res.json({ resolved: true });
});

module.exports = router;
