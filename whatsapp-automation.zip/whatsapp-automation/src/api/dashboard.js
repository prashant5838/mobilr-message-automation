const express = require('express');
const db = require('../db/db');

const router = express.Router();

router.get('/metrics', (req, res) => {
  const totals = db
    .prepare(`
      SELECT
        COUNT(*) FILTER (WHERE direction = 'outbound') AS total_sent,
        COUNT(*) FILTER (WHERE direction = 'outbound' AND status = 'delivered') AS total_delivered,
        COUNT(*) FILTER (WHERE direction = 'outbound' AND status = 'read') AS total_read,
        COUNT(*) FILTER (WHERE direction = 'outbound' AND status = 'failed') AS total_failed,
        COUNT(*) FILTER (WHERE direction = 'inbound') AS total_replies
      FROM messages
    `)
    .get();

  const byTrigger = db
    .prepare(`
      SELECT trigger_event, COUNT(*) as count,
        SUM(CASE WHEN status IN ('delivered','read') THEN 1 ELSE 0 END) as delivered,
        SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed
      FROM messages
      WHERE trigger_event IS NOT NULL
      GROUP BY trigger_event
    `)
    .all();

  const campaigns = db.prepare('SELECT * FROM campaigns ORDER BY created_at DESC LIMIT 20').all();

  const optOuts = db.prepare(`SELECT COUNT(*) as c FROM contacts WHERE opt_status = 'opted_out'`).get();
  const optIns = db.prepare(`SELECT COUNT(*) as c FROM contacts WHERE opt_status = 'opted_in'`).get();

  const pendingHumanAgent = db.prepare(`SELECT COUNT(*) as c FROM contacts WHERE needs_human_agent = 1`).get();

  const intentBreakdown = db
    .prepare(`
      SELECT intent, COUNT(*) as count FROM conversation_events
      WHERE direction = 'inbound' GROUP BY intent ORDER BY count DESC
    `)
    .all();

  const queueDepthByStatus = db
    .prepare(`SELECT status, COUNT(*) as count FROM messages WHERE direction='outbound' GROUP BY status`)
    .all();

  res.json({
    totals,
    deliveryRate: totals.total_sent ? +(totals.total_delivered / totals.total_sent * 100).toFixed(1) : 0,
    readRate: totals.total_sent ? +(totals.total_read / totals.total_sent * 100).toFixed(1) : 0,
    failureRate: totals.total_sent ? +(totals.total_failed / totals.total_sent * 100).toFixed(1) : 0,
    byTrigger,
    campaigns,
    optIns: optIns.c,
    optOuts: optOuts.c,
    pendingHumanAgent: pendingHumanAgent.c,
    intentBreakdown,
    queueDepthByStatus,
  });
});

router.get('/messages', (req, res) => {
  const limit = Math.min(Number(req.query.limit) || 50, 500);
  const rows = db
    .prepare(`
      SELECT m.*, c.phone_e164, c.name
      FROM messages m JOIN contacts c ON c.id = m.contact_id
      ORDER BY m.created_at DESC LIMIT ?
    `)
    .all(limit);
  res.json(rows);
});

module.exports = router;
