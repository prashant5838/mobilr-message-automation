const express = require('express');
const triggers = require('../events/triggers');

const router = express.Router();

/**
 * In production these are not called by a human — an internal event bus /
 * order-management service (e.g. via SQS/RabbitMQ topic or an internal
 * webhook) invokes them when order state changes. Exposed as REST here so
 * the pipeline can be triggered and demoed end-to-end.
 */
router.post('/order-placed', async (req, res) => {
  const result = await triggers.onOrderPlaced(req.body);
  res.status(202).json(result);
});

router.post('/order-shipped', async (req, res) => {
  const result = await triggers.onOrderShipped(req.body);
  res.status(202).json(result);
});

router.post('/out-for-delivery', async (req, res) => {
  const result = await triggers.onOutForDelivery(req.body);
  res.status(202).json(result);
});

router.post('/delivered', async (req, res) => {
  const result = await triggers.onDelivered(req.body);
  res.status(202).json(result);
});

router.post('/payment-failed', async (req, res) => {
  const result = await triggers.onPaymentFailed(req.body);
  res.status(202).json(result);
});

router.post('/cart-updated', async (req, res) => {
  const result = await triggers.onCartUpdated(req.body);
  res.status(202).json(result);
});

router.post('/cart-converted', async (req, res) => {
  const result = await triggers.onCartConverted(req.body.cartId);
  res.status(202).json(result);
});

module.exports = router;
