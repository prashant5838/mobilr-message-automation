const express = require('express');
const templates = require('../whatsapp/templates');

const router = express.Router();

router.get('/', (req, res) => {
  res.json(templates.list({ status: req.query.status }));
});

router.post('/', (req, res) => {
  const { name, category, language, components } = req.body;
  if (!name || !category || !language || !components) {
    return res.status(400).json({ error: 'name, category, language, components are required' });
  }
  const tpl = templates.createDraft({ name, category, language, components });
  res.status(201).json(tpl);
});

router.post('/:id/new-version', (req, res) => {
  const { name, language, components } = req.body;
  const tpl = templates.createNewVersion(name, language, components);
  res.status(201).json(tpl);
});

router.post('/:id/localize', (req, res) => {
  const { name, baseLanguage, targetLanguage, components } = req.body;
  const tpl = templates.localize(name, baseLanguage, targetLanguage, components);
  res.status(201).json(tpl);
});

router.post('/:id/submit', async (req, res) => {
  try {
    const tpl = await templates.submitForApproval(Number(req.params.id));
    res.json(tpl);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

router.post('/:id/refresh-status', async (req, res) => {
  try {
    const tpl = await templates.refreshApprovalStatus(Number(req.params.id));
    res.json(tpl);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

module.exports = router;
