const express = require('express');
const pinoHttp = require('pino-http');
const config = require('./config');
const logger = require('./utils/logger');

const whatsappWebhook = require('./webhooks/whatsappWebhook');
const dashboardApi = require('./api/dashboard');
const templatesApi = require('./api/templates');
const campaignsApi = require('./api/campaigns');
const eventsApi = require('./api/events');
const contactsApi = require('./api/contacts');

const app = express();

// Capture raw body for webhook signature verification, while still
// providing parsed JSON elsewhere.
app.use(
  express.json({
    verify: (req, res, buf) => {
      req.rawBody = buf;
    },
  })
);

app.use(pinoHttp({ logger, autoLogging: { ignore: (req) => req.url === '/healthz' } }));

app.get('/healthz', (req, res) => res.json({ ok: true, mockMode: config.mockMode }));

// Public: Meta calls this directly.
app.use('/webhooks/whatsapp', whatsappWebhook);

// Admin/internal routes — require a shared-secret API key.
function requireAdminKey(req, res, next) {
  if (req.headers['x-api-key'] !== config.adminApiKey) return res.status(401).json({ error: 'unauthorized' });
  next();
}

app.use('/api/dashboard', requireAdminKey, dashboardApi);
app.use('/api/templates', requireAdminKey, templatesApi);
app.use('/api/campaigns', requireAdminKey, campaignsApi);
app.use('/api/events', requireAdminKey, eventsApi); // internal order-service -> this service
app.use('/api/contacts', requireAdminKey, contactsApi);

app.use((err, req, res, next) => {
  logger.error({ err: err.message }, 'Unhandled error');
  res.status(500).json({ error: 'internal_error' });
});

module.exports = app;
