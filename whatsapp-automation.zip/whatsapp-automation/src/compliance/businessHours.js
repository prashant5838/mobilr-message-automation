const config = require('../config');

/**
 * Returns true if "now" (in the configured business timezone) falls within
 * the allowed promotional-send window. Transactional/UTILITY messages are
 * NOT gated by this — see outboundWorker.js.
 */
function isWithinBusinessHours(date = new Date()) {
  const { start, end, timezone } = config.businessHours;
  const hour = Number(
    new Intl.DateTimeFormat('en-US', { hour: 'numeric', hour12: false, timeZone: timezone }).format(date)
  );
  return hour >= start && hour < end;
}

module.exports = { isWithinBusinessHours };
