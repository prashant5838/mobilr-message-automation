const db = require('../db/db');

function getContactByPhone(phone) {
  return db.prepare('SELECT * FROM contacts WHERE phone_e164 = ?').get(phone);
}

function upsertContact({ phone, name, locale }) {
  const existing = getContactByPhone(phone);
  if (existing) return existing;
  db.prepare(`
    INSERT INTO contacts (phone_e164, name, locale, opt_status)
    VALUES (?, ?, ?, 'opted_in')
  `).run(phone, name || null, locale || 'en');
  return getContactByPhone(phone);
}

/**
 * Change a contact's consent status and append an immutable audit record.
 * `source` should describe how consent changed: 'inbound_stop', 'admin_manual',
 * 'checkout_optin', 'api', etc. Every call is logged, opt-in or opt-out.
 */
function setOptStatus(phone, newStatus, { source, rawMessage } = {}) {
  const contact = upsertContact({ phone });
  const previousStatus = contact.opt_status;

  db.prepare(`UPDATE contacts SET opt_status = ?, updated_at = datetime('now') WHERE id = ?`).run(
    newStatus,
    contact.id
  );

  db.prepare(`
    INSERT INTO consent_audit_log (contact_id, previous_status, new_status, source, raw_message)
    VALUES (?, ?, ?, ?, ?)
  `).run(contact.id, previousStatus, newStatus, source || 'unknown', rawMessage || null);

  return getContactByPhone(phone);
}

function optOut(phone, rawMessage) {
  return setOptStatus(phone, 'opted_out', { source: 'inbound_stop', rawMessage });
}

function optIn(phone, source = 'api') {
  return setOptStatus(phone, 'opted_in', { source });
}

function getAuditLog(contactId) {
  return db
    .prepare('SELECT * FROM consent_audit_log WHERE contact_id = ? ORDER BY created_at DESC')
    .all(contactId);
}

function segmentAudience({ tags = [], optStatus = 'opted_in' } = {}) {
  const rows = db.prepare('SELECT * FROM contacts WHERE opt_status = ?').all(optStatus);
  if (!tags.length) return rows;
  return rows.filter((c) => {
    const contactTags = JSON.parse(c.segment_tags || '[]');
    return tags.some((t) => contactTags.includes(t));
  });
}

module.exports = { getContactByPhone, upsertContact, setOptStatus, optOut, optIn, getAuditLog, segmentAudience };
