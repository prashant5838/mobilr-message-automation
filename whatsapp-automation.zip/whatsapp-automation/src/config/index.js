require('dotenv').config();

function required(name, fallback = undefined) {
  const v = process.env[name] ?? fallback;
  if (v === undefined) {
    // Don't throw at import time in dev/mock mode — surfaced instead when the
    // WhatsApp client actually tries to make a call.
    return undefined;
  }
  return v;
}

module.exports = {
  port: Number(process.env.PORT || 3000),
  nodeEnv: process.env.NODE_ENV || 'development',
  adminApiKey: process.env.ADMIN_API_KEY || 'dev-admin-key',

  redisUrl: process.env.REDIS_URL || 'redis://localhost:6379',
  dbPath: process.env.DB_PATH || './data/app.db',

  whatsapp: {
    phoneNumberId: required('WA_PHONE_NUMBER_ID'),
    businessAccountId: required('WA_BUSINESS_ACCOUNT_ID'),
    accessToken: required('WA_ACCESS_TOKEN'),
    apiVersion: process.env.WA_API_VERSION || 'v20.0',
    webhookVerifyToken: process.env.WA_WEBHOOK_VERIFY_TOKEN || 'change-me-verify-token',
    appSecret: process.env.WA_APP_SECRET,
    maxMsgsPerSecond: Number(process.env.WA_MAX_MSGS_PER_SECOND || 20),
  },

  businessHours: {
    start: Number(process.env.BUSINESS_HOURS_START || 9),
    end: Number(process.env.BUSINESS_HOURS_END || 20),
    timezone: process.env.BUSINESS_TIMEZONE || 'Asia/Kolkata',
  },

  cart: {
    abandonDelayMinutes: Number(process.env.CART_ABANDON_DELAY_MINUTES || 120),
  },

  // If no WA credentials are present, the whatsapp client runs in mock mode:
  // it logs the payload it *would* send instead of calling the Graph API.
  // This lets the whole pipeline (queues, workers, webhook parsing, dashboard)
  // be exercised without live WhatsApp credentials.
  get mockMode() {
    return !(this.whatsapp.phoneNumberId && this.whatsapp.accessToken);
  },
};
