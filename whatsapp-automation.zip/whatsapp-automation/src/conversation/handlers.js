const db = require('../db/db');
const waClient = require('../whatsapp/client');
const logger = require('../utils/logger');
const { optOut, optIn, upsertContact } = require('../compliance/optIn');

function logConversationEvent({ contactId, direction, intent, rawText, orderRef, handledBy }) {
  db.prepare(`
    INSERT INTO conversation_events (contact_id, direction, intent, raw_text, order_ref, handled_by)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(contactId, direction, intent, rawText || null, orderRef || null, handledBy || 'bot');
}

async function handleTrackOrder(contact, parsed) {
  // In production this calls the order-management service. Mocked here.
  const status = mockOrderLookup(parsed.orderRef);
  const reply = status
    ? `📦 Order ${parsed.orderRef}: ${status.state}. Estimated delivery: ${status.eta}.`
    : `Sorry, I couldn't find order ${parsed.orderRef}. Please double-check the order number or type CANCEL to reach an agent.`;
  await waClient.sendTextMessage({ to: contact.phone_e164, text: reply });
  logConversationEvent({
    contactId: contact.id,
    direction: 'outbound',
    intent: 'track_order',
    rawText: reply,
    orderRef: parsed.orderRef,
    handledBy: 'bot',
  });
}

async function handleTrackOrderPrompt(contact) {
  const reply = 'Sure — reply with TRACK <order id>, e.g. "TRACK 10234", and I\'ll pull up the latest status.';
  await waClient.sendTextMessage({ to: contact.phone_e164, text: reply });
}

async function handleStop(contact, parsed) {
  optOut(contact.phone_e164, parsed.raw);
  const reply = "You've been unsubscribed from WhatsApp updates. Reply START anytime to opt back in.";
  await waClient.sendTextMessage({ to: contact.phone_e164, text: reply });
  logConversationEvent({ contactId: contact.id, direction: 'outbound', intent: 'stop', rawText: reply, handledBy: 'bot' });
}

async function handleStart(contact) {
  optIn(contact.phone_e164, 'inbound_start');
  const reply = "You're subscribed to order and shipping updates again. Welcome back!";
  await waClient.sendTextMessage({ to: contact.phone_e164, text: reply });
  logConversationEvent({ contactId: contact.id, direction: 'outbound', intent: 'start', rawText: reply, handledBy: 'bot' });
}

async function handleCancel(contact, parsed) {
  // Order cancellation touches money/inventory — route to a human agent
  // rather than auto-cancelling from a bot.
  db.prepare(`UPDATE contacts SET needs_human_agent = 1 WHERE id = ?`).run(contact.id);
  const reply = parsed.orderRef
    ? `Got it — flagging order ${parsed.orderRef} for cancellation. A support agent will confirm with you shortly.`
    : "I've flagged your account for a support agent to help with cancellation. They'll reach out shortly.";
  await waClient.sendTextMessage({ to: contact.phone_e164, text: reply });
  logConversationEvent({
    contactId: contact.id,
    direction: 'outbound',
    intent: 'cancel',
    rawText: reply,
    orderRef: parsed.orderRef,
    handledBy: 'human',
  });
}

async function handleUnknown(contact, parsed) {
  db.prepare(`UPDATE contacts SET needs_human_agent = 1 WHERE id = ?`).run(contact.id);
  const reply =
    "Thanks for your message! I've passed this along to our support team and someone will reply shortly. " +
    'You can also reply TRACK <order id> or CANCEL for quick help.';
  await waClient.sendTextMessage({ to: contact.phone_e164, text: reply });
  logConversationEvent({
    contactId: contact.id,
    direction: 'outbound',
    intent: 'unknown',
    rawText: parsed.raw,
    handledBy: 'unhandled',
  });
  logger.info({ contactId: contact.id, text: parsed.raw }, 'Routed to human agent queue');
}

function mockOrderLookup(orderRef) {
  const states = ['Order confirmed', 'Preparing for shipment', 'Out for delivery', 'Delivered'];
  if (!orderRef) return null;
  const idx = Math.abs(hashCode(orderRef)) % states.length;
  return { state: states[idx], eta: idx < 3 ? 'tomorrow, by 8 PM' : 'delivered' };
}
function hashCode(s) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h << 5) - h + s.charCodeAt(i);
  return h;
}

const HANDLERS = {
  track_order: handleTrackOrder,
  track_order_prompt: handleTrackOrderPrompt,
  stop: handleStop,
  start: handleStart,
  cancel: handleCancel,
  unknown: handleUnknown,
};

async function routeIntent(contact, parsed) {
  logConversationEvent({
    contactId: contact.id,
    direction: 'inbound',
    intent: parsed.intent,
    rawText: parsed.raw,
    orderRef: parsed.orderRef,
    handledBy: parsed.intent === 'unknown' ? 'unhandled' : 'bot',
  });
  const handler = HANDLERS[parsed.intent] || handleUnknown;
  return handler(contact, parsed);
}

module.exports = { routeIntent };
