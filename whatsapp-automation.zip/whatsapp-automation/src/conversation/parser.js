/**
 * Parses inbound free-text WhatsApp replies into a structured intent.
 * Case-insensitive, tolerant of surrounding whitespace and punctuation.
 *
 * Supported commands:
 *   TRACK <order_id>   -> { intent: 'track_order', orderRef }
 *   STOP / UNSUBSCRIBE  -> { intent: 'stop' }
 *   START / SUBSCRIBE   -> { intent: 'start' }
 *   CANCEL <order_id>?  -> { intent: 'cancel', orderRef? }
 *   anything else       -> { intent: 'unknown' } (routed to human agent)
 */
function parseInboundText(rawText) {
  const text = (rawText || '').trim();
  const normalized = text.toUpperCase();

  // "Track Order" is the literal quick-reply button label, not a real order id.
  if (normalized === 'TRACK ORDER') return { intent: 'track_order_prompt', raw: text };

  const trackMatch = normalized.match(/^TRACK\s+([A-Z0-9\-#]+)$/);
  if (trackMatch) {
    return { intent: 'track_order', orderRef: trackMatch[1].replace('#', ''), raw: text };
  }

  if (/^(STOP|UNSUBSCRIBE|OPT[\s-]?OUT)$/.test(normalized)) {
    return { intent: 'stop', raw: text };
  }

  if (/^(START|SUBSCRIBE|OPT[\s-]?IN)$/.test(normalized)) {
    return { intent: 'start', raw: text };
  }

  // "Cancel Order" is the literal quick-reply button label, not a real order id.
  if (normalized === 'CANCEL ORDER') return { intent: 'cancel', orderRef: null, raw: text };

  const cancelMatch = normalized.match(/^CANCEL(?:\s+([A-Z0-9\-#]+))?$/);
  if (cancelMatch) {
    return { intent: 'cancel', orderRef: cancelMatch[1] ? cancelMatch[1].replace('#', '') : null, raw: text };
  }

  return { intent: 'unknown', raw: text };
}

module.exports = { parseInboundText };
