-- Contacts: one row per WhatsApp-addressable customer
CREATE TABLE IF NOT EXISTS contacts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  phone_e164 TEXT UNIQUE NOT NULL,
  name TEXT,
  locale TEXT DEFAULT 'en',
  opt_status TEXT NOT NULL DEFAULT 'opted_in' CHECK (opt_status IN ('opted_in','opted_out','unknown')),
  segment_tags TEXT DEFAULT '[]',      -- JSON array, e.g. ["vip","mumbai","repeat_buyer"]
  last_inbound_at TEXT,
  needs_human_agent INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Opt-in/opt-out audit trail (immutable, append-only)
CREATE TABLE IF NOT EXISTS consent_audit_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  contact_id INTEGER NOT NULL REFERENCES contacts(id),
  previous_status TEXT,
  new_status TEXT NOT NULL,
  source TEXT NOT NULL,               -- 'inbound_stop', 'admin_manual', 'checkout_optin', 'api'
  raw_message TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Message templates registered with WhatsApp (mirrors Meta's template object)
CREATE TABLE IF NOT EXISTS templates (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,                 -- e.g. order_confirmation
  category TEXT NOT NULL CHECK (category IN ('UTILITY','MARKETING','AUTHENTICATION')),
  language TEXT NOT NULL DEFAULT 'en_US',
  version INTEGER NOT NULL DEFAULT 1,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','pending','approved','rejected','disabled')),
  components_json TEXT NOT NULL,      -- WhatsApp template component definition (header/body/buttons)
  wa_template_id TEXT,                -- id returned by Graph API once created
  rejection_reason TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(name, language, version)
);

-- Every outbound message we attempt, keyed for delivery-receipt correlation
CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  wa_message_id TEXT UNIQUE,          -- returned by Graph API on send
  contact_id INTEGER NOT NULL REFERENCES contacts(id),
  direction TEXT NOT NULL CHECK (direction IN ('outbound','inbound')),
  trigger_event TEXT,                 -- 'order_placed','order_shipped','cart_abandoned', etc. NULL for broadcast
  campaign_id INTEGER REFERENCES campaigns(id),
  template_name TEXT,
  body_preview TEXT,
  status TEXT NOT NULL DEFAULT 'queued'
    CHECK (status IN ('queued','sent','delivered','read','failed','replied')),
  error_code TEXT,
  error_detail TEXT,
  attempt_count INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  sent_at TEXT,
  delivered_at TEXT,
  read_at TEXT,
  failed_at TEXT
);

-- Broadcast campaigns (marketing sends, audience-segmented, throttled)
CREATE TABLE IF NOT EXISTS campaigns (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  template_name TEXT NOT NULL,
  template_language TEXT NOT NULL DEFAULT 'en_US',
  segment_filter_json TEXT NOT NULL DEFAULT '{}',  -- e.g. {"tags":["vip"],"opt_status":"opted_in"}
  status TEXT NOT NULL DEFAULT 'draft'
    CHECK (status IN ('draft','scheduled','running','paused','completed','cancelled')),
  scheduled_at TEXT,
  throttle_per_second INTEGER NOT NULL DEFAULT 10,
  total_recipients INTEGER NOT NULL DEFAULT 0,
  sent_count INTEGER NOT NULL DEFAULT 0,
  delivered_count INTEGER NOT NULL DEFAULT 0,
  read_count INTEGER NOT NULL DEFAULT 0,
  failed_count INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Conversation events for two-way parsing / human handoff
CREATE TABLE IF NOT EXISTS conversation_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  contact_id INTEGER NOT NULL REFERENCES contacts(id),
  direction TEXT NOT NULL CHECK (direction IN ('inbound','outbound')),
  intent TEXT,                        -- 'track_order','stop','cancel','unknown','human_handoff'
  raw_text TEXT,
  order_ref TEXT,
  handled_by TEXT DEFAULT 'bot' CHECK (handled_by IN ('bot','human','unhandled')),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_messages_contact ON messages(contact_id);
CREATE INDEX IF NOT EXISTS idx_messages_status ON messages(status);
CREATE INDEX IF NOT EXISTS idx_messages_campaign ON messages(campaign_id);
CREATE INDEX IF NOT EXISTS idx_contacts_phone ON contacts(phone_e164);
CREATE INDEX IF NOT EXISTS idx_conv_events_contact ON conversation_events(contact_id);
