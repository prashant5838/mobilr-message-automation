const db = require('./db');
const { PREBUILT_TEMPLATES } = require('../whatsapp/prebuiltTemplates');

const insertContact = db.prepare(`
  INSERT OR IGNORE INTO contacts (phone_e164, name, locale, opt_status, segment_tags)
  VALUES (?, ?, ?, ?, ?)
`);

const contacts = [
  ['+919876500001', 'Ananya Rao', 'en', 'opted_in', '["vip","bengaluru"]'],
  ['+919876500002', 'Rahul Mehta', 'en', 'opted_in', '["repeat_buyer"]'],
  ['+919876500003', 'Priya Nair', 'hi', 'opted_in', '["new_customer"]'],
  ['+919876500004', 'Karan Shah', 'en', 'opted_out', '[]'],
  ['+919876500005', 'Divya Iyer', 'en', 'opted_in', '["vip"]'],
];
for (const c of contacts) insertContact.run(...c);

const insertTemplate = db.prepare(`
  INSERT OR IGNORE INTO templates (name, category, language, version, status, components_json, wa_template_id)
  VALUES (?, ?, ?, 1, 'approved', ?, ?)
`);
for (const t of PREBUILT_TEMPLATES) {
  insertTemplate.run(
    t.name,
    t.category,
    t.language,
    JSON.stringify(t.components),
    `wa_${t.name}_mock_id`
  );
}

const insertCampaign = db.prepare(`
  INSERT INTO campaigns
    (name, template_name, template_language, segment_filter_json, status, throttle_per_second,
     total_recipients, sent_count, delivered_count, read_count, failed_count)
  VALUES (?, ?, ?, ?, 'completed', ?, ?, ?, ?, ?, ?)
`);
insertCampaign.run(
  'Diwali Sale Broadcast',
  'promo_broadcast',
  'en_US',
  '{"tags":["vip","repeat_buyer"],"opt_status":"opted_in"}',
  20,
  480,
  480,
  462,
  301,
  18
);

const contactRows = db.prepare('SELECT id FROM contacts').all();
const insertMsg = db.prepare(`
  INSERT INTO messages
    (contact_id, direction, trigger_event, template_name, body_preview, status, sent_at, delivered_at, read_at)
  VALUES (?, 'outbound', ?, ?, ?, ?, datetime('now','-1 hour'), datetime('now','-58 minutes'), datetime('now','-40 minutes'))
`);
const sample = [
  ['order_placed', 'order_confirmation', 'Your order #10234 is confirmed!', 'read'],
  ['order_shipped', 'shipping_update', 'Your order #10235 has shipped.', 'delivered'],
  ['cart_abandoned', 'cart_abandonment', 'You left something in your cart 🛒', 'sent'],
];
contactRows.forEach((c, i) => {
  const s = sample[i % sample.length];
  insertMsg.run(c.id, s[0], s[1], s[2], s[3]);
});

console.log('Seed complete.');
