const db = require('../db/db');
const config = require('../config');
const { outboundQueue, scheduledQueue } = require('../queues');
const templates = require('../whatsapp/templates');
const { upsertContact } = require('../compliance/optIn');
const logger = require('../utils/logger');

/**
 * Each trigger:
 *  1. Resolves/creates the contact
 *  2. Looks up the approved template for the event
 *  3. Inserts a `messages` row (status='queued') for audit/dashboard tracking
 *  4. Enqueues an outbound-messages job (rate-limited + retried by the worker)
 *
 * See docs/message-flows.md for a diagram of each flow.
 */

const EVENT_TEMPLATE_MAP = {
  order_placed: 'order_confirmation',
  order_shipped: 'shipping_update',
  out_for_delivery: 'shipping_update',
  delivered: 'shipping_update',
  payment_failed: 'payment_failed', // register this template separately (UTILITY) via the template API
  cart_abandoned: 'cart_abandonment',
};

async function enqueueEventSend({ event, phone, name, locale = 'en_US', variables = [], headerVariables = [] }) {
  const templateName = EVENT_TEMPLATE_MAP[event];
  if (!templateName) throw new Error(`No template mapped for event '${event}'`);

  const tpl = templates.getApproved(templateName, locale) || templates.getApproved(templateName, 'en_US');
  if (!tpl) {
    logger.error({ event, templateName, locale }, 'No approved template available — send skipped');
    return { skipped: true, reason: 'template_not_approved' };
  }

  const contact = upsertContact({ phone, name, locale });

  const messageRow = db
    .prepare(`
      INSERT INTO messages (contact_id, direction, trigger_event, template_name, body_preview, status)
      VALUES (?, 'outbound', ?, ?, ?, 'queued')
    `)
    .run(contact.id, event, templateName, `${event}: ${variables.join(', ')}`);

  await outboundQueue.add('send', {
    messageRowId: messageRow.lastInsertRowid,
    to: contact.phone_e164,
    templateName,
    language: tpl.language,
    variables,
    headerVariables,
    category: tpl.category,
  });

  return { queued: true, messageRowId: messageRow.lastInsertRowid };
}

// --- Order lifecycle triggers -------------------------------------------------

async function onOrderPlaced({ phone, name, orderId, amount, locale }) {
  return enqueueEventSend({
    event: 'order_placed',
    phone,
    name,
    locale,
    variables: [name || 'there', orderId, amount],
  });
}

async function onOrderShipped({ phone, name, orderId, eta, locale }) {
  return enqueueEventSend({
    event: 'order_shipped',
    phone,
    name,
    locale,
    variables: [name || 'there', orderId, 'on its way', eta],
  });
}

async function onOutForDelivery({ phone, name, orderId, eta, locale }) {
  return enqueueEventSend({
    event: 'out_for_delivery',
    phone,
    name,
    locale,
    variables: [name || 'there', orderId, 'out for delivery', eta],
  });
}

async function onDelivered({ phone, name, orderId, locale }) {
  return enqueueEventSend({
    event: 'delivered',
    phone,
    name,
    locale,
    variables: [name || 'there', orderId, 'delivered', 'today'],
  });
}

async function onPaymentFailed({ phone, name, orderId, retryUrl, locale }) {
  return enqueueEventSend({
    event: 'payment_failed',
    phone,
    name,
    locale,
    variables: [name || 'there', orderId, retryUrl],
  });
}

// --- Cart abandonment (delayed trigger) ---------------------------------------

/**
 * Called when a cart is created/updated. Schedules a delayed check; if the
 * cart is still unconverted after CART_ABANDON_DELAY_MINUTES, the scheduled
 * worker sends the nudge. Re-adding for the same cartId with a new job
 * effectively debounces earlier scheduled checks (see startCartWatch).
 */
async function onCartUpdated({ phone, name, cartId, itemsSummary, locale }) {
  const delayMs = config.cart.abandonDelayMinutes * 60 * 1000;
  await scheduledQueue.add(
    'cart-abandon-check',
    { phone, name, cartId, itemsSummary, locale },
    { delay: delayMs, jobId: `cart-${cartId}` } // jobId dedupes: re-adding replaces the pending check
  );
  return { scheduled: true, delayMs };
}

/** Called by checkout when a cart converts, to cancel any pending nudge. */
async function onCartConverted(cartId) {
  const job = await scheduledQueue.getJob(`cart-${cartId}`);
  if (job) await job.remove();
  return { cancelled: !!job };
}

module.exports = {
  enqueueEventSend,
  onOrderPlaced,
  onOrderShipped,
  onOutForDelivery,
  onDelivered,
  onPaymentFailed,
  onCartUpdated,
  onCartConverted,
};
