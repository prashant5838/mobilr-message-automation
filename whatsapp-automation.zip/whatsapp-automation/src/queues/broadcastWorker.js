const { Worker } = require('bullmq');
const { connection, outboundQueue } = require('./index');
const db = require('../db/db');
const logger = require('../utils/logger');
const { segmentAudience } = require('../compliance/optIn');
const templates = require('../whatsapp/templates');

/**
 * job.data = { campaignId }
 * Resolves the audience segment, then enqueues one outbound job per
 * recipient. Pacing across the *campaign's* throttle is achieved by
 * spacing each job's `delay` — this lets a single campaign run below its
 * configured throttle_per_second even when the global outbound worker
 * concurrency is higher (multiple campaigns can then interleave fairly).
 */
async function processCampaign(job) {
  const { campaignId } = job.data;
  const campaign = db.prepare('SELECT * FROM campaigns WHERE id = ?').get(campaignId);
  if (!campaign) throw new Error(`Campaign ${campaignId} not found`);

  const tpl = templates.getApproved(campaign.template_name, campaign.template_language);
  if (!tpl) {
    db.prepare(`UPDATE campaigns SET status = 'cancelled' WHERE id = ?`).run(campaignId);
    throw new Error(`Template '${campaign.template_name}' is not approved — cannot run campaign`);
  }

  const filter = JSON.parse(campaign.segment_filter_json || '{}');
  const audience = segmentAudience({ tags: filter.tags || [], optStatus: filter.opt_status || 'opted_in' });

  db.prepare(`UPDATE campaigns SET status = 'running', total_recipients = ?, updated_at = datetime('now') WHERE id = ?`).run(
    audience.length,
    campaignId
  );

  const throttle = campaign.throttle_per_second || 10;
  const gapMs = Math.ceil(1000 / throttle);

  let i = 0;
  for (const contact of audience) {
    const messageRow = db
      .prepare(`
        INSERT INTO messages (contact_id, direction, campaign_id, template_name, body_preview, status)
        VALUES (?, 'outbound', ?, ?, ?, 'queued')
      `)
      .run(contact.id, campaignId, campaign.template_name, `Broadcast: ${campaign.name}`);

    await outboundQueue.add(
      'send',
      {
        messageRowId: messageRow.lastInsertRowid,
        to: contact.phone_e164,
        templateName: campaign.template_name,
        language: campaign.template_language,
        variables: [contact.name || 'there'],
        category: tpl.category,
      },
      { delay: i * gapMs }
    );
    i += 1;
  }

  db.prepare(`UPDATE campaigns SET sent_count = ?, status = 'completed', updated_at = datetime('now') WHERE id = ?`).run(
    audience.length,
    campaignId
  );

  logger.info({ campaignId, recipients: audience.length }, 'Campaign fanned out to outbound queue');
  return { recipients: audience.length };
}

function startBroadcastWorker() {
  const worker = new Worker('broadcast-campaigns', processCampaign, { connection, concurrency: 2 });
  worker.on('failed', (job, err) => logger.error({ jobId: job?.id, err: err.message }, 'Campaign dispatch failed'));
  return worker;
}

module.exports = { startBroadcastWorker, processCampaign };
