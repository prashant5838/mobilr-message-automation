const { Worker } = require('bullmq');
const { connection } = require('./index');
const db = require('../db/db');
const logger = require('../utils/logger');
const { parseInboundText } = require('../conversation/parser');
const { routeIntent } = require('../conversation/handlers');
const { upsertContact } = require('../compliance/optIn');

/**
 * job.data is a raw WhatsApp webhook "change" entry — either a message
 * event (customer replied) or a status event (delivery receipt).
 * See docs/message-flows.md for the payload shapes.
 */
async function processInboundEvent(job) {
  const { kind, payload } = job.data;
  if (kind === 'message') return handleInboundMessage(payload);
  if (kind === 'status') return handleStatusReceipt(payload);
  logger.warn({ kind }, 'Unknown inbound event kind');
}

async function handleInboundMessage(msg) {
  const phone = `+${msg.from}`;
  const contact = upsertContact({ phone, name: msg.profileName });

  db.prepare(`UPDATE contacts SET last_inbound_at = datetime('now') WHERE id = ?`).run(contact.id);

  // Buttons/quick replies arrive with msg.button.text or msg.interactive.button_reply.title
  const text =
    msg.text?.body ||
    msg.button?.text ||
    msg.interactive?.button_reply?.title ||
    '';

  const parsed = parseInboundText(text);
  logger.info({ phone, text, intent: parsed.intent }, 'Inbound message parsed');

  db.prepare(`
    INSERT INTO messages (contact_id, direction, body_preview, status)
    VALUES (?, 'inbound', ?, 'delivered')
  `).run(contact.id, text.slice(0, 200));

  await routeIntent(contact, parsed);
}

async function handleStatusReceipt(status) {
  // status: { id: wa_message_id, status: 'sent'|'delivered'|'read'|'failed', errors?: [...] }
  const fieldMap = { sent: 'sent_at', delivered: 'delivered_at', read: 'read_at', failed: 'failed_at' };
  const timeField = fieldMap[status.status];

  const row = db.prepare('SELECT id, campaign_id FROM messages WHERE wa_message_id = ?').get(status.id);
  if (!row) {
    logger.warn({ waMessageId: status.id }, 'Delivery receipt for unknown message');
    return;
  }

  const updates = ['status = ?'];
  const values = [status.status];
  if (timeField) {
    updates.push(`${timeField} = datetime('now')`);
  }
  if (status.status === 'failed' && status.errors?.length) {
    updates.push('error_code = ?', 'error_detail = ?');
    values.push(String(status.errors[0].code), status.errors[0].title || '');
  }
  values.push(row.id);
  db.prepare(`UPDATE messages SET ${updates.join(', ')} WHERE id = ?`).run(...values);

  if (row.campaign_id) {
    const col = { delivered: 'delivered_count', read: 'read_count', failed: 'failed_count' }[status.status];
    if (col) db.prepare(`UPDATE campaigns SET ${col} = ${col} + 1 WHERE id = ?`).run(row.campaign_id);
  }
}

function startInboundWorker() {
  const worker = new Worker('inbound-events', processInboundEvent, { connection, concurrency: 10 });
  worker.on('failed', (job, err) => logger.error({ jobId: job?.id, err: err.message }, 'Inbound event processing failed'));
  return worker;
}

module.exports = { startInboundWorker, processInboundEvent };
