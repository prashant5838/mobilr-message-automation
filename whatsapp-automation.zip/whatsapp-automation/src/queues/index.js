const { Queue } = require('bullmq');
const IORedis = require('ioredis');
const config = require('../config');

const connection = new IORedis(config.redisUrl, { maxRetriesPerRequest: null });

// Individual outbound sends (order events + campaign fan-out land here).
// Retries use exponential backoff; a global rate limiter is applied on the
// Worker side (see outboundWorker.js) to respect WhatsApp's per-second cap.
const outboundQueue = new Queue('outbound-messages', {
  connection,
  defaultJobOptions: {
    attempts: 5,
    backoff: { type: 'exponential', delay: 2000 }, // 2s, 4s, 8s, 16s, 32s
    removeOnComplete: { age: 3600, count: 5000 },
    removeOnFail: { age: 86400 },
  },
});

// Campaign orchestration: one job per campaign, fans out into outboundQueue.
const campaignQueue = new Queue('broadcast-campaigns', {
  connection,
  defaultJobOptions: { attempts: 2, removeOnComplete: true },
});

// Inbound webhook events (messages + status receipts) processed off the
// HTTP request path so the webhook responds to Meta within their timeout.
const inboundQueue = new Queue('inbound-events', {
  connection,
  defaultJobOptions: { attempts: 5, backoff: { type: 'exponential', delay: 1000 }, removeOnComplete: true },
});

// Delayed jobs for time-based triggers (cart abandonment > 2h).
const scheduledQueue = new Queue('scheduled-triggers', {
  connection,
  defaultJobOptions: { attempts: 5, backoff: { type: 'exponential', delay: 2000 }, removeOnComplete: true },
});

module.exports = { connection, outboundQueue, campaignQueue, inboundQueue, scheduledQueue };
