const { Worker } = require('bullmq');
const { connection } = require('./index');
const config = require('../config');
const db = require('../db/db');
const waClient = require('../whatsapp/client');
const templates = require('../whatsapp/templates');
const logger = require('../utils/logger');
const { isWithinBusinessHours } = require('../compliance/businessHours');
const { getContactByPhone } = require('../compliance/optIn');

/**
 * Job payload shape:
 * {
 *   messageRowId,      // row already inserted into `messages` with status='queued'
 *   to,                // E.164 phone
 *   templateName, language,
 *   variables: [...],  // positional {{n}} values for BODY
 *   headerVariables: [...],
 *   category,          // 'UTILITY' | 'MARKETING' — used for business-hours gating
 * }
 */
async function processOutbound(job) {
  const { messageRowId, to, templateName, language, variables = [], headerVariables = [], category } = job.data;

  const contact = getContactByPhone(to);
  if (!contact || contact.opt_status === 'opted_out') {
    markMessage(messageRowId, 'failed', { error_code: 'OPTED_OUT', error_detail: 'Recipient has opted out' });
    logger.warn({ to }, 'Skipped send: recipient opted out');
    return { skipped: true, reason: 'opted_out' };
  }

  // Marketing (promotional) sends respect business hours; transactional
  // (UTILITY) messages are service notifications the user is expecting and
  // are exempt, matching WhatsApp's own commerce-policy guidance.
  if (category === 'MARKETING' && !isWithinBusinessHours()) {
    const err = new Error('Outside business hours — will retry within window');
    err.retryDelayMs = minutesUntilBusinessHoursOpen() * 60 * 1000;
    throw err; // BullMQ retry/backoff will re-attempt; see backoff strategy override below
  }

  const tpl = templates.getApproved(templateName, language);
  if (!tpl) {
    markMessage(messageRowId, 'failed', {
      error_code: 'TEMPLATE_NOT_APPROVED',
      error_detail: `No approved template '${templateName}' (${language})`,
    });
    // Non-retryable — fail the job permanently.
    throw new UnrecoverableError(`Template '${templateName}' not approved for ${language}`);
  }

  const components = [];
  if (headerVariables.length) {
    components.push({ type: 'header', parameters: headerVariables.map((t) => ({ type: 'text', text: String(t) })) });
  }
  if (variables.length) {
    components.push({ type: 'body', parameters: variables.map((t) => ({ type: 'text', text: String(t) })) });
  }

  try {
    const result = await waClient.sendTemplateMessage({
      to,
      templateName: tpl.wa_template_id?.startsWith('mock') ? templateName : templateName,
      languageCode: language,
      components,
    });
    const waMessageId = result.messages?.[0]?.id;
    markMessage(messageRowId, 'sent', { wa_message_id: waMessageId, sent_at: nowSql() });
    return { sent: true, waMessageId };
  } catch (err) {
    const detail = err.response?.data || err.message;
    markMessage(messageRowId, 'failed', {
      error_code: err.response?.status || 'SEND_ERROR',
      error_detail: JSON.stringify(detail).slice(0, 500),
    });
    throw err; // let BullMQ apply exponential backoff / retry budget
  }
}

function markMessage(id, status, extra = {}) {
  const fields = ['status = ?'];
  const values = [status];
  for (const [k, v] of Object.entries(extra)) {
    fields.push(`${k} = ?`);
    values.push(v);
  }
  values.push(id);
  db.prepare(`UPDATE messages SET ${fields.join(', ')}, attempt_count = attempt_count + 1 WHERE id = ?`).run(...values);
}

function nowSql() {
  return new Date().toISOString().replace('T', ' ').slice(0, 19);
}

function minutesUntilBusinessHoursOpen() {
  const { start } = config.businessHours;
  const now = new Date();
  const opensAt = new Date(now);
  opensAt.setHours(start, 0, 0, 0);
  if (opensAt <= now) opensAt.setDate(opensAt.getDate() + 1);
  return Math.ceil((opensAt - now) / 60000);
}

// Minimal Unrecoverable marker so BullMQ stops retrying template-not-approved errors.
class UnrecoverableError extends Error {}

function startOutboundWorker() {
  const worker = new Worker('outbound-messages', processOutbound, {
    connection,
    // Global throughput cap respecting WhatsApp's per-second messaging limit.
    limiter: { max: config.whatsapp.maxMsgsPerSecond, duration: 1000 },
    concurrency: config.whatsapp.maxMsgsPerSecond,
  });

  worker.on('failed', (job, err) => {
    logger.error({ jobId: job?.id, err: err.message, attemptsMade: job?.attemptsMade }, 'Outbound send failed');
  });
  worker.on('completed', (job, result) => {
    if (!result?.skipped) logger.info({ jobId: job.id, to: job.data.to }, 'Outbound send completed');
  });

  return worker;
}

module.exports = { startOutboundWorker, processOutbound };
