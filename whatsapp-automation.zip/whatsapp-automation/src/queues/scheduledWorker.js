const { Worker } = require('bullmq');
const { connection } = require('./index');
const { enqueueEventSend } = require('../events/triggers');
const logger = require('../utils/logger');

/**
 * Fires CART_ABANDON_DELAY_MINUTES after the last cart update, unless the
 * job was removed by onCartConverted() in the meantime (see triggers.js).
 */
async function processScheduledTrigger(job) {
  if (job.name === 'cart-abandon-check') {
    const { phone, name, cartId, itemsSummary, locale } = job.data;
    logger.info({ cartId, phone }, 'Cart still abandoned — sending nudge');
    return enqueueEventSend({
      event: 'cart_abandoned',
      phone,
      name,
      locale,
      variables: [name || 'there', itemsSummary],
    });
  }
  logger.warn({ jobName: job.name }, 'Unknown scheduled trigger job');
}

function startScheduledWorker() {
  const worker = new Worker('scheduled-triggers', processScheduledTrigger, { connection, concurrency: 5 });
  worker.on('failed', (job, err) => logger.error({ jobId: job?.id, err: err.message }, 'Scheduled trigger failed'));
  return worker;
}

module.exports = { startScheduledWorker };
