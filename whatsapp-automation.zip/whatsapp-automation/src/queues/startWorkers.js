const logger = require('../utils/logger');
const { startOutboundWorker } = require('./outboundWorker');
const { startBroadcastWorker } = require('./broadcastWorker');
const { startInboundWorker } = require('./inboundWorker');
const { startScheduledWorker } = require('./scheduledWorker');

startOutboundWorker();
startBroadcastWorker();
startInboundWorker();
startScheduledWorker();

logger.info('All workers started: outbound, broadcast, inbound, scheduled');

process.on('SIGTERM', () => {
  logger.info('SIGTERM received, shutting down workers');
  process.exit(0);
});
