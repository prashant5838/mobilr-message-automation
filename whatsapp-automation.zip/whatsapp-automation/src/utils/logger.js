const pino = require('pino');
const config = require('../config');

module.exports = pino({
  level: config.nodeEnv === 'test' ? 'silent' : 'info',
  transport: config.nodeEnv === 'development'
    ? { target: 'pino-pretty', options: { colorize: true, translateTime: 'HH:MM:ss' } }
    : undefined,
});
