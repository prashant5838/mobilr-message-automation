const express = require('express');
const crypto = require('crypto');
const config = require('../config');
const logger = require('../utils/logger');
const { inboundQueue } = require('../queues');

const router = express.Router();

// --- 1. Verification handshake (Meta calls this once when you set the webhook URL) ---
router.get('/', (req, res) => {
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];

  if (mode === 'subscribe' && token === config.whatsapp.webhookVerifyToken) {
    logger.info('Webhook verified successfully');
    return res.status(200).send(challenge);
  }
  return res.sendStatus(403);
});

// --- 2. Signature validation middleware ---
function verifySignature(req, res, next) {
  if (!config.whatsapp.appSecret) return next(); // skip in mock/dev mode
  const signature = req.headers['x-hub-signature-256'];
  if (!signature) return res.sendStatus(401);

  const expected =
    'sha256=' + crypto.createHmac('sha256', config.whatsapp.appSecret).update(req.rawBody || '').digest('hex');
  const valid =
    signature.length === expected.length &&
    crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected));
  if (!valid) {
    logger.warn('Webhook signature mismatch — rejecting');
    return res.sendStatus(401);
  }
  next();
}

// --- 3. Inbound events: messages + delivery/read receipts ---
// Respond 200 immediately (Meta expects a fast ack) and push heavier
// processing onto the inbound-events queue.
router.post('/', verifySignature, async (req, res) => {
  try {
    const entries = req.body?.entry || [];
    for (const entry of entries) {
      for (const change of entry.changes || []) {
        const value = change.value || {};

        for (const msg of value.messages || []) {
          await inboundQueue.add('message', {
            kind: 'message',
            payload: { ...msg, profileName: value.contacts?.[0]?.profile?.name },
          });
        }

        for (const status of value.statuses || []) {
          await inboundQueue.add('status', { kind: 'status', payload: status });
        }
      }
    }
    res.sendStatus(200);
  } catch (err) {
    logger.error({ err: err.message }, 'Webhook processing error');
    // Still 200 — Meta retries aggressively on non-2xx, which can duplicate
    // work; failures here are recoverable via the queue's own retry/log.
    res.sendStatus(200);
  }
});

module.exports = router;
