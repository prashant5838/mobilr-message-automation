const axios = require('axios');
const config = require('../config');
const logger = require('../utils/logger');

const BASE = () => `https://graph.facebook.com/${config.whatsapp.apiVersion}`;

function authHeaders() {
  return { Authorization: `Bearer ${config.whatsapp.accessToken}`, 'Content-Type': 'application/json' };
}

/**
 * Thin wrapper around the WhatsApp Business Cloud API.
 * Falls back to "mock mode" (logs instead of calling Meta) when no
 * WA_ACCESS_TOKEN / WA_PHONE_NUMBER_ID is configured, so the rest of the
 * pipeline (queues, retries, webhook handling, dashboard) can be exercised
 * end-to-end without live credentials.
 */
class WhatsAppClient {
  async sendTemplateMessage({ to, templateName, languageCode, components = [] }) {
    if (config.mockMode) {
      logger.info({ to, templateName, languageCode, components }, '[MOCK] sendTemplateMessage');
      return { messages: [{ id: `mock-${Date.now()}-${Math.random().toString(36).slice(2, 8)}` }] };
    }
    const url = `${BASE()}/${config.whatsapp.phoneNumberId}/messages`;
    const body = {
      messaging_product: 'whatsapp',
      to,
      type: 'template',
      template: { name: templateName, language: { code: languageCode }, components },
    };
    const { data } = await axios.post(url, body, { headers: authHeaders() });
    return data;
  }

  async sendTextMessage({ to, text, previewUrl = false }) {
    if (config.mockMode) {
      logger.info({ to, text }, '[MOCK] sendTextMessage');
      return { messages: [{ id: `mock-${Date.now()}-${Math.random().toString(36).slice(2, 8)}` }] };
    }
    const url = `${BASE()}/${config.whatsapp.phoneNumberId}/messages`;
    const body = {
      messaging_product: 'whatsapp',
      to,
      type: 'text',
      text: { body: text, preview_url: previewUrl },
    };
    const { data } = await axios.post(url, body, { headers: authHeaders() });
    return data;
  }

  async markAsRead(messageId) {
    if (config.mockMode) {
      logger.info({ messageId }, '[MOCK] markAsRead');
      return { success: true };
    }
    const url = `${BASE()}/${config.whatsapp.phoneNumberId}/messages`;
    const body = { messaging_product: 'whatsapp', status: 'read', message_id: messageId };
    const { data } = await axios.post(url, body, { headers: authHeaders() });
    return data;
  }

  /** Create (submit for approval) a message template on the WhatsApp Business Account. */
  async createTemplate({ name, category, language, components }) {
    if (config.mockMode) {
      logger.info({ name, category, language }, '[MOCK] createTemplate -> submitted for review');
      return { id: `mock_template_${name}_${language}`, status: 'PENDING' };
    }
    const url = `${BASE()}/${config.whatsapp.businessAccountId}/message_templates`;
    const body = { name, category, language, components };
    const { data } = await axios.post(url, body, { headers: authHeaders() });
    return data; // { id, status: 'PENDING' | 'APPROVED' | 'REJECTED' }
  }

  /** Poll current approval status for a template (Meta reviews async, usually mins-hours). */
  async getTemplateStatus(waTemplateId) {
    if (config.mockMode) {
      return { id: waTemplateId, status: 'APPROVED' };
    }
    const url = `${BASE()}/${waTemplateId}`;
    const { data } = await axios.get(url, { headers: authHeaders(), params: { fields: 'status,rejected_reason' } });
    return data;
  }
}

module.exports = new WhatsAppClient();
