/**
 * Pre-built templates in the exact shape Meta's Graph API expects for
 * POST /{whatsapp-business-account-id}/message_templates.
 * {{1}}, {{2}}... are positional variables filled in at send time.
 */
const PREBUILT_TEMPLATES = [
  {
    name: 'order_confirmation',
    category: 'UTILITY',
    language: 'en_US',
    components: [
      { type: 'HEADER', format: 'TEXT', text: 'Order Confirmed ✅' },
      {
        type: 'BODY',
        text:
          'Hi {{1}}, thanks for your order! Order #{{2}} for {{3}} has been confirmed and is being prepared. ' +
          "We'll notify you the moment it ships.",
        example: { body_text: [['Ananya', '10234', '₹2,499']] },
      },
      { type: 'FOOTER', text: 'Reply TRACK <order id> anytime for status.' },
      {
        type: 'BUTTONS',
        buttons: [
          { type: 'URL', text: 'View Order', url: 'https://shop.example.com/orders/{{1}}', example: ['10234'] },
          { type: 'QUICK_REPLY', text: 'Cancel Order' },
        ],
      },
    ],
  },
  {
    name: 'shipping_update',
    category: 'UTILITY',
    language: 'en_US',
    components: [
      { type: 'HEADER', format: 'TEXT', text: 'Shipping Update 📦' },
      {
        type: 'BODY',
        text:
          'Hi {{1}}, your order #{{2}} is {{3}}. Estimated delivery: {{4}}.',
        example: { body_text: [['Rahul', '10235', 'out for delivery', 'today by 8 PM']] },
      },
      { type: 'FOOTER', text: 'Reply TRACK {{1}} for live status.' },
      {
        type: 'BUTTONS',
        buttons: [
          { type: 'URL', text: 'Track Package', url: 'https://shop.example.com/track/{{1}}', example: ['10235'] },
        ],
      },
    ],
  },
  {
    name: 'cart_abandonment',
    category: 'MARKETING',
    language: 'en_US',
    components: [
      { type: 'HEADER', format: 'TEXT', text: 'You left something behind 🛒' },
      {
        type: 'BODY',
        text:
          'Hi {{1}}, you still have {{2}} waiting in your cart. Complete your purchase in the next 24 hours ' +
          'and get free shipping!',
        example: { body_text: [['Divya', '2 items worth ₹1,899']] },
      },
      { type: 'FOOTER', text: 'Reply STOP to opt out of promos anytime.' },
      {
        type: 'BUTTONS',
        buttons: [
          { type: 'URL', text: 'Complete Purchase', url: 'https://shop.example.com/cart/{{1}}', example: ['c9981'] },
        ],
      },
    ],
  },
];

module.exports = { PREBUILT_TEMPLATES };
