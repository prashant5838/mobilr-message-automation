const db = require('../db/db');
const waClient = require('./client');
const logger = require('../utils/logger');

/** Create a new draft template (v1) in our DB, not yet submitted to Meta. */
function createDraft({ name, category, language, components }) {
  const stmt = db.prepare(`
    INSERT INTO templates (name, category, language, version, status, components_json)
    VALUES (?, ?, ?, 1, 'draft', ?)
  `);
  const info = stmt.run(name, category, language, JSON.stringify(components));
  return getById(info.lastInsertRowid);
}

/** Create a new version of an existing template (e.g. after a rejection or content change). */
function createNewVersion(name, language, components) {
  const latest = db
    .prepare('SELECT MAX(version) as v FROM templates WHERE name = ? AND language = ?')
    .get(name, language);
  const nextVersion = (latest?.v || 0) + 1;
  const category = db
    .prepare('SELECT category FROM templates WHERE name = ? AND language = ? ORDER BY version DESC LIMIT 1')
    .get(name, language)?.category || 'UTILITY';

  const stmt = db.prepare(`
    INSERT INTO templates (name, category, language, version, status, components_json)
    VALUES (?, ?, ?, ?, 'draft', ?)
  `);
  const info = stmt.run(name, category, language, nextVersion, JSON.stringify(components));
  return getById(info.lastInsertRowid);
}

/** Add a localized variant of an existing template under the same name. */
function localize(name, baseLanguage, targetLanguage, translatedComponents) {
  const base = db
    .prepare('SELECT * FROM templates WHERE name = ? AND language = ? ORDER BY version DESC LIMIT 1')
    .get(name, baseLanguage);
  if (!base) throw new Error(`No base template '${name}' (${baseLanguage}) to localize from`);

  const stmt = db.prepare(`
    INSERT INTO templates (name, category, language, version, status, components_json)
    VALUES (?, ?, ?, 1, 'draft', ?)
  `);
  const info = stmt.run(name, base.category, targetLanguage, JSON.stringify(translatedComponents));
  return getById(info.lastInsertRowid);
}

/** Submit a draft template to Meta for review. */
async function submitForApproval(templateId) {
  const tpl = getById(templateId);
  if (!tpl) throw new Error('Template not found');
  if (tpl.status !== 'draft' && tpl.status !== 'rejected') {
    throw new Error(`Template is '${tpl.status}', only draft/rejected templates can be (re)submitted`);
  }

  const waName = tpl.version > 1 ? `${tpl.name}_v${tpl.version}` : tpl.name;
  const result = await waClient.createTemplate({
    name: waName,
    category: tpl.category,
    language: tpl.language,
    components: JSON.parse(tpl.components_json),
  });

  db.prepare(`
    UPDATE templates SET status = 'pending', wa_template_id = ?, updated_at = datetime('now') WHERE id = ?
  `).run(result.id, templateId);

  logger.info({ templateId, waTemplateId: result.id }, 'Template submitted for approval');
  return getById(templateId);
}

/** Poll Meta for the current approval status and sync our local record. */
async function refreshApprovalStatus(templateId) {
  const tpl = getById(templateId);
  if (!tpl || !tpl.wa_template_id) throw new Error('Template not submitted yet');

  const remote = await waClient.getTemplateStatus(tpl.wa_template_id);
  const status = String(remote.status || '').toLowerCase(); // approved | rejected | pending
  db.prepare(`
    UPDATE templates
    SET status = ?, rejection_reason = ?, updated_at = datetime('now')
    WHERE id = ?
  `).run(status, remote.rejected_reason || null, templateId);

  return getById(templateId);
}

function getById(id) {
  const row = db.prepare('SELECT * FROM templates WHERE id = ?').get(id);
  return row ? { ...row, components: JSON.parse(row.components_json) } : null;
}

function getApproved(name, language) {
  const row = db
    .prepare(`
      SELECT * FROM templates
      WHERE name = ? AND language = ? AND status = 'approved'
      ORDER BY version DESC LIMIT 1
    `)
    .get(name, language);
  return row ? { ...row, components: JSON.parse(row.components_json) } : null;
}

function list({ status } = {}) {
  const rows = status
    ? db.prepare('SELECT * FROM templates WHERE status = ? ORDER BY name, language, version DESC').all(status)
    : db.prepare('SELECT * FROM templates ORDER BY name, language, version DESC').all();
  return rows.map((r) => ({ ...r, components: JSON.parse(r.components_json) }));
}

module.exports = {
  createDraft,
  createNewVersion,
  localize,
  submitForApproval,
  refreshApprovalStatus,
  getById,
  getApproved,
  list,
};
