const test = require('node:test');
const assert = require('node:assert/strict');
const { parseInboundText } = require('../src/conversation/parser');

test('parses TRACK with order id', () => {
  assert.deepEqual(parseInboundText('track 10234').intent, 'track_order');
  assert.equal(parseInboundText('TRACK #10234').orderRef, '10234');
  assert.equal(parseInboundText('  Track 10234  ').orderRef, '10234');
});

test('parses STOP / UNSUBSCRIBE variants', () => {
  assert.equal(parseInboundText('stop').intent, 'stop');
  assert.equal(parseInboundText('STOP').intent, 'stop');
  assert.equal(parseInboundText('unsubscribe').intent, 'stop');
  assert.equal(parseInboundText('opt-out').intent, 'stop');
});

test('parses START / SUBSCRIBE variants', () => {
  assert.equal(parseInboundText('start').intent, 'start');
  assert.equal(parseInboundText('SUBSCRIBE').intent, 'start');
});

test('parses CANCEL with and without order id', () => {
  assert.equal(parseInboundText('cancel').intent, 'cancel');
  assert.equal(parseInboundText('cancel').orderRef, null);
  const withId = parseInboundText('CANCEL 10234');
  assert.equal(withId.intent, 'cancel');
  assert.equal(withId.orderRef, '10234');
});

test('quick-reply button payloads map to intents', () => {
  assert.equal(parseInboundText('Cancel Order').intent, 'cancel');
  assert.equal(parseInboundText('Track Order').intent, 'track_order_prompt');
});

test('falls back to unknown for free text', () => {
  assert.equal(parseInboundText('hey is my refund processed?').intent, 'unknown');
  assert.equal(parseInboundText('').intent, 'unknown');
});
